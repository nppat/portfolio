$(document).ready(function(){
	$("#tabs").tabs({
		event: "mouseover"
	});
});